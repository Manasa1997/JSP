package com.cg.library;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;



public class SelectLibrary {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("librarymanagement");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
	//	Library l1=new Library();
		Query q=em.createNamedQuery("select_lib");
		List<Library> list=q.getResultList();
		for(Library lib:list){
			System.out.println("=======");
			System.out.println("Id:"+lib.getId());
			System.out.println("name:"+lib.getBookName());
			System.out.println("Price:"+lib.getBookPrice());
		}
		em.getTransaction().commit();
	
	}

}
