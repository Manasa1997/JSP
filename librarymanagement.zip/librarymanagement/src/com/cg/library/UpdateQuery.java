package com.cg.library;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UpdateQuery {

	public static void main(String[] args) {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("librarymanagement");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		/*System.out.println("Enter id");
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
	
		Library l3=em.find(Library.class,id);
		sc.nextLine();;
		System.out.println("Enter boook name");
		String b=sc.nextLine();
		l3.setBookName(b);
		
		System.out.println("Enter price");
		double p=sc.nextDouble();
		l3.setBookPrice(p);
		System.out.println("updated");
		em.getTransaction().commit();*/
	
		
	Library lib=em.find(Library.class,3);
		if(lib!=null){
			lib.setBookName("react");
			lib.setBookPrice(1000);
			em.persist(lib);
			
		}else
		{
			System.out.println("boook doesn't exist with this id");
		}
		em.getTransaction().commit();
	}
	}

