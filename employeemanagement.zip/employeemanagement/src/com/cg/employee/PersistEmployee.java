package com.cg.employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistEmployee {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("employeemanagement");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Employee e=new Employee();
e.setId(1);
e.setName("Manasa");
e.setSalary(20000);

Employee e1=new Employee();
e1.setId(2);
e1.setName("Mounika");
e1.setSalary(25000);
em.persist(e);
em.persist(e1);
em.getTransaction().commit();
em.close();
emf.close();
	}

}
