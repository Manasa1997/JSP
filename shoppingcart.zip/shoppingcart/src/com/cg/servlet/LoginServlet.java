package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
		HttpSession hs=request.getSession();
		hs.setAttribute("uname", username);
		Cookie c1 =new Cookie("uname",username);
		Cookie c2 =new Cookie("pass",password);
		response.addCookie(c1);
		response.addCookie(c2);
		ServletContext sc=getServletContext();
		try{
			Class.forName(sc.getInitParameter("driver_class"));        
			String url=sc.getInitParameter("url");
			String user=sc.getInitParameter("user");
			String pass=sc.getInitParameter("password");
			Connection con=DriverManager.getConnection(url,user,pass);
			System.out.println("db connected");
		}catch(Exception e){
			e.printStackTrace();
		}
		/*out.println("<html>");
		out.println("<body bgcolor='white'>");
		out.println("<p>Welcome Miss."+username+"</p>");
		out.println("<p>You entered password:"+password+"</p>");
		out.println("</body></html>");*/
	ServletConfig s=getServletConfig();
		if(username.equals(s.getInitParameter("username"))&&password.equals(s.getInitParameter("password")))
		{
			/*RequestDispatcher rd=request.getRequestDispatcher("https://www.google.co.in/");
			rd.forward(request,response);*/
			response.sendRedirect("welcome.jsp");
		}
		else
		{
			out.print("<b style='color:red'>User is not registered so please do register</b>");
			RequestDispatcher rd=request.getRequestDispatcher("registration.jsp");
			rd.include(request,response);
		}
	}

}







